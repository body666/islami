import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class RadioTab extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return const Placeholder(color:Colors.blueAccent,);
  }
}
